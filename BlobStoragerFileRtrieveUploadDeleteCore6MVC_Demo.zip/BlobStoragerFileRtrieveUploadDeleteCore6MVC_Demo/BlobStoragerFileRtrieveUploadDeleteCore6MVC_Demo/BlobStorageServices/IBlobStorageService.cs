﻿using BlobStoragerFileRtrieveUploadDeleteCore6MVC_Demo.Models;

namespace BlobStoragerFileRtrieveUploadDeleteCore6MVC_Demo.BlobStorageServices
{
    public interface IBlobStorageService
    {
        Task<List<BlobStorage>> GetAllBlobFiles();
        Task UploadBlobFileAsync(IFormFile files);
        Task DeleteDocumentAsync(string blobName);
    }
}
